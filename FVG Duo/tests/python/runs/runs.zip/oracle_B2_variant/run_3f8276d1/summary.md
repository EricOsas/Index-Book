# FVG Duo Run Summary

Config hash: `3f8276d1`

| Metric | Value |
|---|---|
| trade_count | 3107 |
| net_usd | 386782.04 |
| gross_points | 20004.0 |
| win_rate | 50.31 |
| profit_factor | 1.258 |
| green_years | 15 |
| max_dd_closed | 38379.04 |
| net_last_365 | 97229.56 |
| net_last_100 | 55302.0 |
| net_first_half | 24373.16 |
| net_second_half | 362408.88 |
| net_near_roll | 29963.6 |
| net_no_roll | 356818.44 |
| od_long_net | 169690.04 |
| od_short_net | 129216.28 |