# FVG Duo Run Summary

Config hash: `0f8b2a0b`

| Metric | Value |
|---|---|
| trade_count | 3251 |
| net_usd | 429070.72 |
| gross_points | 22149.25 |
| win_rate | 51.12 |
| profit_factor | 1.284 |
| green_years | 15 |
| max_dd_closed | 35839.04 |
| net_last_365 | 108393.12 |
| net_last_100 | 59712.0 |
| net_first_half | 30560.0 |
| net_second_half | 398510.72 |
| net_near_roll | 27227.2 |
| net_no_roll | 401843.52 |
| od_long_net | 173452.92 |
| od_short_net | 129216.28 |