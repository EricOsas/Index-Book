# FVG Duo Run Summary

Config hash: `08401aba`

| Metric | Value |
|---|---|
| trade_count | 2820 |
| net_usd | 390420.4 |
| gross_points | 20124.5 |
| win_rate | 51.56 |
| profit_factor | 1.277 |
| green_years | 16 |
| max_dd_closed | 35937.64 |
| net_last_365 | 89714.48 |
| net_last_100 | 61197.0 |
| net_first_half | 39845.2 |
| net_second_half | 350575.2 |
| net_near_roll | 27508.56 |
| net_no_roll | 362911.84 |
| od_long_net | 180574.4 |
| od_short_net | 138956.28 |