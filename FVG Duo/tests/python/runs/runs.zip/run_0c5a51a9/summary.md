# FVG Duo Run Summary

Config hash: `0c5a51a9`

| Metric | Value |
|---|---|
| trade_count | 2798 |
| net_usd | 421759.56 |
| gross_points | 21686.75 |
| win_rate | 51.36 |
| profit_factor | 1.312 |
| green_years | 16 |
| max_dd_closed | 29738.36 |
| net_last_365 | 94775.16 |
| net_last_100 | 62512.0 |
| net_first_half | 43492.28 |
| net_second_half | 378267.28 |
| net_near_roll | 29616.4 |
| net_no_roll | 392143.16 |
| od_long_net | 185523.72 |
| od_short_net | 144181.28 |