# FVG Duo Run Summary

Config hash: `1d14e577`

| Metric | Value |
|---|---|
| trade_count | 1708 |
| net_usd | 216134.76 |
| gross_points | 11172.25 |
| win_rate | 49.06 |
| profit_factor | 1.384 |
| green_years | 15 |
| max_dd_closed | 22408.88 |
| net_last_365 | 50345.48 |
| net_last_100 | 42707.0 |
| net_first_half | 9609.88 |
| net_second_half | 206524.88 |
| net_near_roll | 536.04 |
| net_no_roll | 215598.72 |
| od_long_net | 0 |
| od_short_net | 0 |