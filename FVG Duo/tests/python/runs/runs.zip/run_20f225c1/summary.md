# FVG Duo Run Summary

Config hash: `20f225c1`

| Metric | Value |
|---|---|
| trade_count | 2798 |
| net_usd | 348089.56 |
| gross_points | 18003.25 |
| win_rate | 48.75 |
| profit_factor | 1.269 |
| green_years | 15 |
| max_dd_closed | 38139.68 |
| net_last_365 | 81665.16 |
| net_last_100 | 51177.0 |
| net_first_half | 36642.28 |
| net_second_half | 311447.28 |
| net_near_roll | 9471.4 |
| net_no_roll | 338618.16 |
| od_long_net | 125993.72 |
| od_short_net | 129741.28 |