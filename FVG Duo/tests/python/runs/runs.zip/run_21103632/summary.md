# FVG Duo Run Summary

Config hash: `21103632`

| Metric | Value |
|---|---|
| trade_count | 3251 |
| net_usd | 461575.72 |
| gross_points | 23774.5 |
| win_rate | 51.95 |
| profit_factor | 1.309 |
| green_years | 16 |
| max_dd_closed | 35409.04 |
| net_last_365 | 110103.12 |
| net_last_100 | 60712.0 |
| net_first_half | 46805.0 |
| net_second_half | 414770.72 |
| net_near_roll | 28577.2 |
| net_no_roll | 432998.52 |
| od_long_net | 183562.92 |
| od_short_net | 138956.28 |