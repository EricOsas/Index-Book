# FVG Duo Run Summary

Config hash: `31c52fea`

| Metric | Value |
|---|---|
| trade_count | 3107 |
| net_usd | 343917.04 |
| gross_points | 17860.75 |
| win_rate | 48.41 |
| profit_factor | 1.244 |
| green_years | 15 |
| max_dd_closed | 46426.08 |
| net_last_365 | 77044.56 |
| net_last_100 | 38437.0 |
| net_first_half | 39983.16 |
| net_second_half | 303933.88 |
| net_near_roll | 10198.6 |
| net_no_roll | 333718.44 |
| od_long_net | 121100.04 |
| od_short_net | 129741.28 |