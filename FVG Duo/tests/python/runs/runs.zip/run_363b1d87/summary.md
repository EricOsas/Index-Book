# FVG Duo Run Summary

Config hash: `363b1d87`

| Metric | Value |
|---|---|
| trade_count | 2808 |
| net_usd | 417411.76 |
| gross_points | 21471.5 |
| win_rate | 51.67 |
| profit_factor | 1.302 |
| green_years | 16 |
| max_dd_closed | 32348.36 |
| net_last_365 | 103580.16 |
| net_last_100 | 73407.0 |
| net_first_half | 38265.88 |
| net_second_half | 379145.88 |
| net_near_roll | 26126.4 |
| net_no_roll | 391285.36 |
| od_long_net | 181118.72 |
| od_short_net | 138956.28 |