# FVG Duo Run Summary

Config hash: `3a589061`

| Metric | Value |
|---|---|
| trade_count | 3107 |
| net_usd | 423332.04 |
| gross_points | 21831.5 |
| win_rate | 50.79 |
| profit_factor | 1.289 |
| green_years | 16 |
| max_dd_closed | 35339.04 |
| net_last_365 | 90154.56 |
| net_last_100 | 50892.0 |
| net_first_half | 46163.16 |
| net_second_half | 377168.88 |
| net_near_roll | 30343.6 |
| net_no_roll | 392988.44 |
| od_long_net | 183020.04 |
| od_short_net | 144181.28 |