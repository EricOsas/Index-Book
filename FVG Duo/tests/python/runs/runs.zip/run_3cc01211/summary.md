# FVG Duo Run Summary

Config hash: `3cc01211`

| Metric | Value |
|---|---|
| trade_count | 2922 |
| net_usd | 419338.84 |
| gross_points | 21592.25 |
| win_rate | 51.47 |
| profit_factor | 1.297 |
| green_years | 16 |
| max_dd_closed | 29496.92 |
| net_last_365 | 107155.2 |
| net_last_100 | 72417.0 |
| net_first_half | 36996.92 |
| net_second_half | 382341.92 |
| net_near_roll | 29247.12 |
| net_no_roll | 390091.72 |
| od_long_net | 178597.4 |
| od_short_net | 136463.56 |