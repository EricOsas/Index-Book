# FVG Duo Run Summary

Config hash: `417e0cf0`

| Metric | Value |
|---|---|
| trade_count | 1852 |
| net_usd | 257528.44 |
| gross_points | 13272.75 |
| win_rate | 49.84 |
| profit_factor | 1.429 |
| green_years | 16 |
| max_dd_closed | 16469.56 |
| net_last_365 | 64844.8 |
| net_last_100 | 63122.0 |
| net_first_half | 11956.72 |
| net_second_half | 245571.72 |
| net_near_roll | 7911.08 |
| net_no_roll | 249617.36 |
| od_long_net | 0 |
| od_short_net | 0 |