# FVG Duo Run Summary

Config hash: `450f3655`

| Metric | Value |
|---|---|
| trade_count | 3107 |
| net_usd | 417842.04 |
| gross_points | 21557.0 |
| win_rate | 51.08 |
| profit_factor | 1.281 |
| green_years | 16 |
| max_dd_closed | 37949.04 |
| net_last_365 | 98959.56 |
| net_last_100 | 56302.0 |
| net_first_half | 39893.16 |
| net_second_half | 377948.88 |
| net_near_roll | 31263.6 |
| net_no_roll | 386578.44 |
| od_long_net | 179760.04 |
| od_short_net | 138956.28 |