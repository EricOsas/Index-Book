# FVG Duo Run Summary

Config hash: `4546f346`

| Metric | Value |
|---|---|
| trade_count | 3082 |
| net_usd | 442089.04 |
| gross_points | 22764.0 |
| win_rate | 51.46 |
| profit_factor | 1.305 |
| green_years | 16 |
| max_dd_closed | 30736.92 |
| net_last_365 | 118033.8 |
| net_last_100 | 76722.0 |
| net_first_half | 39509.52 |
| net_second_half | 402579.52 |
| net_near_roll | 29947.16 |
| net_no_roll | 412141.88 |
| od_long_net | 184159.36 |
| od_short_net | 138956.28 |