# FVG Duo Run Summary

Config hash: `49bbeec1`

| Metric | Value |
|---|---|
| trade_count | 2798 |
| net_usd | 383929.56 |
| gross_points | 19795.25 |
| win_rate | 50.93 |
| profit_factor | 1.276 |
| green_years | 15 |
| max_dd_closed | 32718.36 |
| net_last_365 | 102050.16 |
| net_last_100 | 72407.0 |
| net_first_half | 23617.28 |
| net_second_half | 360312.28 |
| net_near_roll | 24926.4 |
| net_no_roll | 359003.16 |
| od_long_net | 170858.72 |
| od_short_net | 129216.28 |