# FVG Duo Run Summary

Config hash: `5de70740`

| Metric | Value |
|---|---|
| trade_count | 2851 |
| net_usd | 405667.72 |
| gross_points | 20893.5 |
| win_rate | 51.53 |
| profit_factor | 1.291 |
| green_years | 16 |
| max_dd_closed | 31277.64 |
| net_last_365 | 103580.16 |
| net_last_100 | 73407.0 |
| net_first_half | 35911.0 |
| net_second_half | 369756.72 |
| net_near_roll | 24832.12 |
| net_no_roll | 380835.6 |
| od_long_net | 175666.0 |
| od_short_net | 136463.56 |