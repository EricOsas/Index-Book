# FVG Duo Run Summary

Config hash: `6109394c`

| Metric | Value |
|---|---|
| trade_count | 1669 |
| net_usd | 220521.68 |
| gross_points | 11383.25 |
| win_rate | 49.49 |
| profit_factor | 1.398 |
| green_years | 14 |
| max_dd_closed | 22408.88 |
| net_last_365 | 50345.48 |
| net_last_100 | 42707.0 |
| net_first_half | 9520.48 |
| net_second_half | 211001.2 |
| net_near_roll | 80.32 |
| net_no_roll | 220441.36 |
| od_long_net | 0 |
| od_short_net | 0 |