# FVG Duo Run Summary

Config hash: `62cf8ae3`

| Metric | Value |
|---|---|
| trade_count | 3133 |
| net_usd | 428580.76 |
| gross_points | 22099.5 |
| win_rate | 51.13 |
| profit_factor | 1.287 |
| green_years | 16 |
| max_dd_closed | 37949.04 |
| net_last_365 | 99940.28 |
| net_last_100 | 56302.0 |
| net_first_half | 46142.52 |
| net_second_half | 382438.24 |
| net_near_roll | 33214.32 |
| net_no_roll | 395366.44 |
| od_long_net | 179760.04 |
| od_short_net | 138956.28 |