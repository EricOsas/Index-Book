# FVG Duo Run Summary

Config hash: `661c7063`

| Metric | Value |
|---|---|
| trade_count | 1556 |
| net_usd | 202365.32 |
| gross_points | 10451.25 |
| win_rate | 48.91 |
| profit_factor | 1.388 |
| green_years | 15 |
| max_dd_closed | 19770.36 |
| net_last_365 | 45510.44 |
| net_last_100 | 41842.0 |
| net_first_half | 9450.16 |
| net_second_half | 192915.16 |
| net_near_roll | 3493.88 |
| net_no_roll | 198871.44 |
| od_long_net | 0 |
| od_short_net | 0 |