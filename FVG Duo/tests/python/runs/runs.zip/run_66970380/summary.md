# FVG Duo Run Summary

Config hash: `66970380`

| Metric | Value |
|---|---|
| trade_count | 2979 |
| net_usd | 440019.88 |
| gross_points | 22638.5 |
| win_rate | 51.93 |
| profit_factor | 1.308 |
| green_years | 16 |
| max_dd_closed | 30567.64 |
| net_last_365 | 109025.92 |
| net_last_100 | 73357.0 |
| net_first_half | 39312.08 |
| net_second_half | 400707.8 |
| net_near_roll | 28035.72 |
| net_no_roll | 411984.16 |
| od_long_net | 178232.28 |
| od_short_net | 138956.28 |