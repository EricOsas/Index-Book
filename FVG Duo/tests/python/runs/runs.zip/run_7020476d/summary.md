# FVG Duo Run Summary

Config hash: `7020476d`

| Metric | Value |
|---|---|
| trade_count | 3035 |
| net_usd | 431220.2 |
| gross_points | 22210.5 |
| win_rate | 51.66 |
| profit_factor | 1.298 |
| green_years | 16 |
| max_dd_closed | 29496.92 |
| net_last_365 | 109025.92 |
| net_last_100 | 73357.0 |
| net_first_half | 38347.24 |
| net_second_half | 392872.96 |
| net_near_roll | 27041.44 |
| net_no_roll | 404178.76 |
| od_long_net | 172779.56 |
| od_short_net | 136463.56 |