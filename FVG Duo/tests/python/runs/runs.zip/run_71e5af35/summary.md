# FVG Duo Run Summary

Config hash: `71e5af35`

| Metric | Value |
|---|---|
| trade_count | 2982 |
| net_usd | 420682.04 |
| gross_points | 21672.25 |
| win_rate | 51.71 |
| profit_factor | 1.293 |
| green_years | 16 |
| max_dd_closed | 29496.92 |
| net_last_365 | 108149.48 |
| net_last_100 | 73277.0 |
| net_first_half | 38788.52 |
| net_second_half | 381893.52 |
| net_near_roll | 24875.72 |
| net_no_roll | 395806.32 |
| od_long_net | 176071.0 |
| od_short_net | 136463.56 |