# FVG Duo Run Summary

Config hash: `73bcd1c1`

| Metric | Value |
|---|---|
| trade_count | 3107 |
| net_usd | 323062.04 |
| gross_points | 16818.0 |
| win_rate | 45.12 |
| profit_factor | 1.251 |
| green_years | 15 |
| max_dd_closed | 47661.08 |
| net_last_365 | 70879.56 |
| net_last_100 | 47072.0 |
| net_first_half | 38218.16 |
| net_second_half | 284843.88 |
| net_near_roll | 22508.6 |
| net_no_roll | 300553.44 |
| od_long_net | 101875.04 |
| od_short_net | 126346.28 |