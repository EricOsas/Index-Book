# FVG Duo Run Summary

Config hash: `73d33141`

| Metric | Value |
|---|---|
| trade_count | 3148 |
| net_usd | 432606.56 |
| gross_points | 22304.0 |
| win_rate | 50.76 |
| profit_factor | 1.292 |
| green_years | 16 |
| max_dd_closed | 35339.04 |
| net_last_365 | 89676.0 |
| net_last_100 | 48242.0 |
| net_first_half | 55223.28 |
| net_second_half | 377383.28 |
| net_near_roll | 32294.32 |
| net_no_roll | 400312.24 |
| od_long_net | 183020.04 |
| od_short_net | 144181.28 |