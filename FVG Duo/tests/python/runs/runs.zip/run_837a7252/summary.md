# FVG Duo Run Summary

Config hash: `837a7252`

| Metric | Value |
|---|---|
| trade_count | 3107 |
| net_usd | 407762.04 |
| gross_points | 21053.0 |
| win_rate | 51.4 |
| profit_factor | 1.27 |
| green_years | 16 |
| max_dd_closed | 33714.04 |
| net_last_365 | 102504.56 |
| net_last_100 | 59627.0 |
| net_first_half | 45303.16 |
| net_second_half | 362458.88 |
| net_near_roll | 29693.6 |
| net_no_roll | 378068.44 |
| od_long_net | 181015.04 |
| od_short_net | 127601.28 |