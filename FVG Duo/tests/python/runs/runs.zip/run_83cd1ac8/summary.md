# FVG Duo Run Summary

Config hash: `83cd1ac8`

| Metric | Value |
|---|---|
| trade_count | 2798 |
| net_usd | 394189.56 |
| gross_points | 20308.25 |
| win_rate | 50.86 |
| profit_factor | 1.298 |
| green_years | 15 |
| max_dd_closed | 40429.0 |
| net_last_365 | 100530.16 |
| net_last_100 | 67767.0 |
| net_first_half | 42347.28 |
| net_second_half | 351842.28 |
| net_near_roll | 26841.4 |
| net_no_roll | 367348.16 |
| od_long_net | 150498.72 |
| od_short_net | 151976.28 |