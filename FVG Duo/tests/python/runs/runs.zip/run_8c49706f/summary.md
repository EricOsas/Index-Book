# FVG Duo Run Summary

Config hash: `8c49706f`

| Metric | Value |
|---|---|
| trade_count | 2798 |
| net_usd | 411859.56 |
| gross_points | 21191.75 |
| win_rate | 51.68 |
| profit_factor | 1.299 |
| green_years | 16 |
| max_dd_closed | 32348.36 |
| net_last_365 | 103580.16 |
| net_last_100 | 73407.0 |
| net_first_half | 37557.28 |
| net_second_half | 374302.28 |
| net_near_roll | 26126.4 |
| net_no_roll | 385733.16 |
| od_long_net | 181118.72 |
| od_short_net | 138956.28 |