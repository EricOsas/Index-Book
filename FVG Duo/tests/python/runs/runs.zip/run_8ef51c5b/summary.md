# FVG Duo Run Summary

Config hash: `8ef51c5b`

| Metric | Value |
|---|---|
| trade_count | 2867 |
| net_usd | 428119.24 |
| gross_points | 22019.5 |
| win_rate | 51.76 |
| profit_factor | 1.307 |
| green_years | 16 |
| max_dd_closed | 30567.64 |
| net_last_365 | 107155.2 |
| net_last_100 | 72417.0 |
| net_first_half | 39716.76 |
| net_second_half | 388402.48 |
| net_near_roll | 30541.4 |
| net_no_roll | 397577.84 |
| od_long_net | 184050.12 |
| od_short_net | 138956.28 |