# FVG Duo Run Summary

Config hash: `a687be9f`

| Metric | Value |
|---|---|
| trade_count | 2798 |
| net_usd | 404964.56 |
| gross_points | 20847.0 |
| win_rate | 52.04 |
| profit_factor | 1.29 |
| green_years | 15 |
| max_dd_closed | 28808.48 |
| net_last_365 | 107125.16 |
| net_last_100 | 76732.0 |
| net_first_half | 41807.28 |
| net_second_half | 363157.28 |
| net_near_roll | 28596.4 |
| net_no_roll | 376368.16 |
| od_long_net | 185988.72 |
| od_short_net | 127601.28 |