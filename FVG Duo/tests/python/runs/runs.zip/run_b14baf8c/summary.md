# FVG Duo Run Summary

Config hash: `b14baf8c`

| Metric | Value |
|---|---|
| trade_count | 3274 |
| net_usd | 408912.28 |
| gross_points | 21146.25 |
| win_rate | 50.61 |
| profit_factor | 1.263 |
| green_years | 15 |
| max_dd_closed | 42381.16 |
| net_last_365 | 87660.32 |
| net_last_100 | 39887.0 |
| net_first_half | 30598.64 |
| net_second_half | 378313.64 |
| net_near_roll | 28312.92 |
| net_no_roll | 380599.36 |
| od_long_net | 169237.88 |
| od_short_net | 129216.28 |