# FVG Duo Run Summary

Config hash: `b1ed962f`

| Metric | Value |
|---|---|
| trade_count | 3107 |
| net_usd | 396742.04 |
| gross_points | 20502.0 |
| win_rate | 50.34 |
| profit_factor | 1.276 |
| green_years | 15 |
| max_dd_closed | 46430.44 |
| net_last_365 | 95909.56 |
| net_last_100 | 54897.0 |
| net_first_half | 45353.16 |
| net_second_half | 351388.88 |
| net_near_roll | 27563.6 |
| net_no_roll | 369178.44 |
| od_long_net | 147830.04 |
| od_short_net | 151976.28 |