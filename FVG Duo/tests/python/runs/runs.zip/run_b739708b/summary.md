# FVG Duo Run Summary

Config hash: `b739708b`

| Metric | Value |
|---|---|
| trade_count | 2024 |
| net_usd | 327797.28 |
| gross_points | 16823.0 |
| win_rate | 53.56 |
| profit_factor | 1.289 |
| green_years | 16 |
| max_dd_closed | 33012.8 |
| net_last_365 | 86717.84 |
| net_last_100 | 65152.0 |
| net_first_half | 53393.64 |
| net_second_half | 274403.64 |
| net_near_roll | 30271.92 |
| net_no_roll | 297525.36 |
| od_long_net | 188841.0 |
| od_short_net | 138956.28 |