# FVG Duo Run Summary

Config hash: `d7928a71`

| Metric | Value |
|---|---|
| trade_count | 2072 |
| net_usd | 319851.84 |
| gross_points | 16436.0 |
| win_rate | 53.33 |
| profit_factor | 1.278 |
| green_years | 15 |
| max_dd_closed | 33012.8 |
| net_last_365 | 86717.84 |
| net_last_100 | 65152.0 |
| net_first_half | 41055.92 |
| net_second_half | 278795.92 |
| net_near_roll | 28839.08 |
| net_no_roll | 291012.76 |
| od_long_net | 183388.28 |
| od_short_net | 136463.56 |