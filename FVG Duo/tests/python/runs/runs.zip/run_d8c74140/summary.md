# FVG Duo Run Summary

Config hash: `d8c74140`

| Metric | Value |
|---|---|
| trade_count | 1894 |
| net_usd | 251918.68 |
| gross_points | 13001.25 |
| win_rate | 49.37 |
| profit_factor | 1.413 |
| green_years | 16 |
| max_dd_closed | 16469.56 |
| net_last_365 | 64844.8 |
| net_last_100 | 63122.0 |
| net_first_half | 11506.84 |
| net_second_half | 240411.84 |
| net_near_roll | 8666.8 |
| net_no_roll | 243251.88 |
| od_long_net | 0 |
| od_short_net | 0 |