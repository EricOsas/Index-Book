# FVG Duo Run Summary

Config hash: `dc809d95`

| Metric | Value |
|---|---|
| trade_count | 2812 |
| net_usd | 424184.64 |
| gross_points | 21811.0 |
| win_rate | 51.28 |
| profit_factor | 1.312 |
| green_years | 16 |
| max_dd_closed | 29738.36 |
| net_last_365 | 94775.16 |
| net_last_100 | 62512.0 |
| net_first_half | 44502.32 |
| net_second_half | 379682.32 |
| net_near_roll | 29616.4 |
| net_no_roll | 394568.24 |
| od_long_net | 185523.72 |
| od_short_net | 144181.28 |