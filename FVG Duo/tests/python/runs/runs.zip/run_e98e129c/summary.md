# FVG Duo Run Summary

Config hash: `e98e129c`

| Metric | Value |
|---|---|
| trade_count | 1594 |
| net_usd | 200047.68 |
| gross_points | 10343.5 |
| win_rate | 48.62 |
| profit_factor | 1.378 |
| green_years | 15 |
| max_dd_closed | 19770.36 |
| net_last_365 | 45510.44 |
| net_last_100 | 41842.0 |
| net_first_half | 8938.84 |
| net_second_half | 191108.84 |
| net_near_roll | 3949.6 |
| net_no_roll | 196098.08 |
| od_long_net | 0 |
| od_short_net | 0 |