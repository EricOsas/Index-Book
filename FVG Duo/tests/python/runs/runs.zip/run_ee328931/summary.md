# FVG Duo Run Summary

Config hash: `ee328931`

| Metric | Value |
|---|---|
| trade_count | 1807 |
| net_usd | 234451.04 |
| gross_points | 12109.25 |
| win_rate | 49.25 |
| profit_factor | 1.396 |
| green_years | 14 |
| max_dd_closed | 24571.72 |
| net_last_365 | 59822.64 |
| net_last_100 | 51862.0 |
| net_first_half | 10300.16 |
| net_second_half | 224150.88 |
| net_near_roll | 6501.08 |
| net_no_roll | 227949.96 |
| od_long_net | 0 |
| od_short_net | 0 |