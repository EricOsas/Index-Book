# FVG Duo Run Summary

Config hash: `f29f04bc`

| Metric | Value |
|---|---|
| trade_count | 2798 |
| net_usd | 324034.56 |
| gross_points | 16800.5 |
| win_rate | 45.07 |
| profit_factor | 1.276 |
| green_years | 15 |
| max_dd_closed | 39374.68 |
| net_last_365 | 75050.16 |
| net_last_100 | 51832.0 |
| net_first_half | 34547.28 |
| net_second_half | 289487.28 |
| net_near_roll | 21781.4 |
| net_no_roll | 302253.16 |
| od_long_net | 106863.72 |
| od_short_net | 126346.28 |