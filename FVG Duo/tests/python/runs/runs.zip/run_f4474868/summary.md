# FVG Duo Run Summary

Config hash: `f4474868`

| Metric | Value |
|---|---|
| trade_count | 3274 |
| net_usd | 441637.28 |
| gross_points | 22782.5 |
| win_rate | 51.41 |
| profit_factor | 1.287 |
| green_years | 16 |
| max_dd_closed | 41911.16 |
| net_last_365 | 89470.32 |
| net_last_100 | 40887.0 |
| net_first_half | 46958.64 |
| net_second_half | 394678.64 |
| net_near_roll | 29672.92 |
| net_no_roll | 411964.36 |
| od_long_net | 179277.88 |
| od_short_net | 138956.28 |