# FVG Duo Run Summary

Config hash: `f4ad0f45`

| Metric | Value |
|---|---|
| trade_count | 2925 |
| net_usd | 429496.0 |
| gross_points | 22100.75 |
| win_rate | 52.0 |
| profit_factor | 1.303 |
| green_years | 16 |
| max_dd_closed | 30567.64 |
| net_last_365 | 108149.48 |
| net_last_100 | 73277.0 |
| net_first_half | 39202.64 |
| net_second_half | 390293.36 |
| net_near_roll | 25870.0 |
| net_no_roll | 403626.0 |
| od_long_net | 181523.72 |
| od_short_net | 138956.28 |