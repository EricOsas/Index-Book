# FVG Duo Run Summary

Config hash: `fbacbba2`

| Metric | Value |
|---|---|
| trade_count | 1766 |
| net_usd | 239881.52 |
| gross_points | 12372.0 |
| win_rate | 49.72 |
| profit_factor | 1.413 |
| green_years | 14 |
| max_dd_closed | 24571.72 |
| net_last_365 | 59822.64 |
| net_last_100 | 51862.0 |
| net_first_half | 10640.76 |
| net_second_half | 229240.76 |
| net_near_roll | 5745.36 |
| net_no_roll | 234136.16 |
| od_long_net | 0 |
| od_short_net | 0 |